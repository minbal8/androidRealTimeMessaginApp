package com.ktuedu.rtMessaging;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DisplayPerson extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_person);

        Person p = getIntent().getParcelableExtra("person");

        TextView name = findViewById(R.id.editTextNameDisplay);
        TextView desc = findViewById(R.id.editTextDescriptionDisplay);
        ImageView image = findViewById(R.id.imageViewDisplay);

        String nameText = "Name: " + p.Name;
        String descText = "Description: " + p.Description;

        name.setText(nameText);
        desc.setText(descText);
        image.setImageResource(p.Photo);

    }
}
