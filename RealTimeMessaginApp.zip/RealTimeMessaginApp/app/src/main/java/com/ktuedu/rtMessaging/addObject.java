package com.ktuedu.rtMessaging;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class addObject extends AppCompatActivity {


    String name;
    String description;

    ImageView imageView;
    EditText nameText;
    EditText descText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_object);

        imageView = findViewById(R.id.imageView);
        Button addObjectButton = findViewById(R.id.addObjectButton);
        imageView.setImageResource(R.drawable.index);
        nameText = findViewById(R.id.editText);
        descText = findViewById(R.id.editText2);

        addObjectButton.setOnClickListener(addObjectListener);
    }



    boolean isGood(){

        if(name == null)
            return false;
        return name.length()>0;// && photo != null;
    }

    View.OnClickListener addObjectListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            name = nameText.getText().toString();
            description = descText.getText().toString();
            if (isGood()) {
                runMainActivity();
            }
        }
    };



    private void runMainActivity() {

        Person p = new Person(
                name,
                R.drawable.index,
                description);
        Log.e("", p.Name + " " + p.Photo);
        Intent intent = new Intent();
        intent.putExtra("person", p);
        setResult(2, intent);
        finish();
    }

}
