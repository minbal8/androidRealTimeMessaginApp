package com.ktuedu.rtMessaging;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class PersonListAdapter extends ArrayAdapter {

    public PersonListAdapter(Context context, List<Person> resources) {
        super(context,R.layout.item_design, resources);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View v = convertView;

        if(v==null){
            LayoutInflater inflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.item_design,null);
        }

        TextView name = v.findViewById(R.id.listItemTitle);
        TextView desc = v.findViewById(R.id.listItemDescription);
        ImageView image = v.findViewById(R.id.listItemImage);

        Person person = (Person)getItem(position);

        name.setText(person.Name);
        desc.setText(person.Description);
        image.setImageResource(person.Photo);

        return v;
    }


}
