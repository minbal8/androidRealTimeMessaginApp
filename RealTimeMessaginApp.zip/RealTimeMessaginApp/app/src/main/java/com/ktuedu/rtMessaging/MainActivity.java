package com.ktuedu.rtMessaging;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;




public class MainActivity extends AppCompatActivity {

    Button addBtn;
    Button sortBtn;
    Context context;
    EditText filterText;
    ArrayList<Person> listOfPersons;
    ArrayList<Person> listOfPersonsFiltered;
    ListView listView;
    ListAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = this;
        listOfPersons = new ArrayList<>();
        addTestResults();
        listView = findViewById(R.id.recyclerView);
        listView.setOnItemClickListener(displayObject);
        listView.setOnItemLongClickListener(removeListItem);
        addBtn = findViewById(R.id.addObject);
        sortBtn = findViewById(R.id.sortObjects);
        filterText = findViewById(R.id.search_editText);


        filterText.addTextChangedListener(watcher);
        addBtn.setOnClickListener(addObjectListener);
        sortBtn.setOnClickListener(sortObjectsListener);
        listOfPersonsFiltered = listOfPersons;
        Button tempFunc = findViewById(R.id.tempButton);

        tempFunc.setOnClickListener(tempFuncListener);

        updateListView();
    }

    TextWatcher watcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence s, int i0, int i1, int i2) {
            if (s.toString().length() > 0 && s.toString().length() < 2) {
                listOfPersonsFiltered = new ArrayList<>();
                for (int i = 0; i < listOfPersons.size(); i++) {
                    Person p = listOfPersons.get(i);
                    if (p.Name.toLowerCase().startsWith(s.toString().toLowerCase())) {
                        listOfPersonsFiltered.add(p);
                    }
                }
            } else {
                listOfPersonsFiltered = listOfPersons;
            }
            updateListView();
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };

    AdapterView.OnItemLongClickListener removeListItem  =new AdapterView.OnItemLongClickListener() {
        @Override
        public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

            Person p = listOfPersonsFiltered.get(i);
            listOfPersons.remove(p);
            listOfPersonsFiltered.remove(i);
            updateListView();
            return true;
        }
    };

    View.OnClickListener addObjectListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            runAddObjectActivity();
        }
    };

    View.OnClickListener tempFuncListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            runTempFuncActivity();
        }
    };

    View.OnClickListener sortObjectsListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Collections.sort(listOfPersonsFiltered);
            updateListView();
        }
    };

    AdapterView.OnItemClickListener displayObject = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            Person p = (Person) adapterView.getItemAtPosition(i);
            runDisplayPersonActivity(p);
        }
    };

    private void runDisplayPersonActivity(Person p) {
        Intent runIntent = new Intent(this, DisplayPerson.class);

        runIntent.putExtra("person", p);
        startActivityForResult(runIntent, 3);
    }

    private void addTestResults() {

        listOfPersons.add(new Person("CTest", R.drawable.index_red, "Description3"));
        listOfPersons.add(new Person("DTest", R.drawable.index_yellow, "Description4"));
        listOfPersons.add(new Person("BTest", R.drawable.index_green, "Description2"));
        listOfPersons.add(new Person("ETest", R.drawable.index_purple, "Description5"));
        listOfPersons.add(new Person("ATest", R.drawable.index_blue, "Description1"));
        listOfPersons.add(new Person("FTest", R.drawable.index_red, "Description3"));
        listOfPersons.add(new Person("GTest", R.drawable.index_yellow, "Description4"));
        listOfPersons.add(new Person("HTest", R.drawable.index_green, "Description2"));
        listOfPersons.add(new Person("ITest", R.drawable.index_purple, "Description5"));
        listOfPersons.add(new Person("JTest", R.drawable.index_blue, "DescriptionStart\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescription1\nDescriptionEnd\n"));


    }

    private void runTempFuncActivity() {
        Intent runIntent = new Intent(this, tempFunctions.class);

        runIntent.putExtra("list", listOfPersons);
        startActivity(runIntent);
    }

    private void runAddObjectActivity() {
        Intent runIntent = new Intent(this, addObject.class);
        startActivityForResult(runIntent, 2);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if (requestCode == 2 && data != null) {
            Person p = data.getParcelableExtra("person");
            Log.e("", p.Name + " " + p.Photo);
            listOfPersons.add(p);
            updateListView();
        }
    }

    public void updateListView() {
        listAdapter = new PersonListAdapter(context, listOfPersonsFiltered);
        listView.setAdapter(listAdapter);
    }
}
