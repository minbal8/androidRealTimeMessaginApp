package com.ktuedu.rtMessaging;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class tempFunctions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp_functions);


        final Button button = findViewById(R.id.removeUiBtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                button.setVisibility(View.INVISIBLE);
            }
        });

        ListView listView = findViewById(R.id.tempFuncListView);
        Intent intent = getIntent();
        if(intent != null && intent.hasExtra("list")) {
            ArrayList<Person> listOfPersons = intent.getParcelableArrayListExtra("list");
            PersonListAdapter listAdapter = new PersonListAdapter(this, listOfPersons);
            listView.setAdapter(listAdapter);
        }
    }
}
