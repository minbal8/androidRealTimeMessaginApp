package com.ktuedu.rtMessaging;

import android.os.Parcel;
import android.os.Parcelable;

public class Person implements Parcelable, Comparable<Person> {

    public String Name;
    public String Description;
    public int Photo;


    public Person(String name, int imageId, String description){
        Name = name;
        Photo = imageId;
        Description = description;
    }

    @Override
    public int compareTo(Person o) {
        return this.Name.toLowerCase().compareTo(o.Name.toLowerCase());
    }


    protected Person(Parcel in) {
        Name = in.readString();
        Description = in.readString();
        Photo = in.readInt();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(Name);
        dest.writeString(Description);
        dest.writeInt(Photo);
    }

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Person> CREATOR = new Parcelable.Creator<Person>() {
        @Override
        public Person createFromParcel(Parcel in) {
            return new Person(in);
        }

        @Override
        public Person[] newArray(int size) {
            return new Person[size];
        }
    };


}
